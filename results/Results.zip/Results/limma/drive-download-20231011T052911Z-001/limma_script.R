library(edgeR)
library(limma)
library(RColorBrewer)
library(dplyr)
library(caret)
setwd("C:/Users/lorie/OneDrive/Bureau/Semester_2/IFN646_BiomedicalDataScience/assessments/project/Project")
## Data Import ####
sample3_dge <- function (filename){
  #Importing the count matrix
  count <- read.delim(paste0("data/",filename,".tsv"))
  
  #Creating Dgelist object
  dg <- DGEList(count)
  
  #Creating groups
  if (substring(filename, 1, 1) == "3"){
    group <- as.factor(c("Condition1", "Condition1", "Condition1", 
                         "Condition2", "Condition2", "Condition2"))  
  }
  else if (substring(filename, 1, 1) == "6"){
    group <- as.factor(c("Condition1", "Condition1", "Condition1", 
                         "Condition1", "Condition1", "Condition1",
                         "Condition2", "Condition2", "Condition2",
                         "Condition2", "Condition2", "Condition2"))
  }
  else if (substring(filename, 1, 1) == "9"){
    group <- as.factor(c("Condition1", "Condition1", "Condition1", 
                         "Condition1", "Condition1", "Condition1",
                         "Condition1", "Condition1", "Condition1",
                         "Condition2", "Condition2", "Condition2",
                         "Condition2", "Condition2", "Condition2",
                         "Condition2", "Condition2", "Condition2"))
  }
  

  
  ## Data preprocessing ####
  
  # Removing genes that are lowly expressed
  keep.exprs <- filterByExpr(dg, group=group)
  dg_low_filtered <- dg[keep.exprs,, keep.lib.sizes=FALSE]
 
  
  #normalisation
  dg <- calcNormFactors(dg, method = "TMM")
  dg_low_filtered <- calcNormFactors(dg_low_filtered, method = "TMM")

  
  #Design matrix
  design <- model.matrix(~0+group)
  colnames(design) <- gsub("group", "", colnames(design))
  design
  
  
  contr.matrix <- makeContrasts(
    Cnd2vsCnd1 = Condition2-Condition1, 
    levels = colnames(design))
  contr.matrix
  
  vdg <- voom(dg, design)
  vdg_low_filtered<- voom(dg_low_filtered, design)

  
  #Fitting linear model
  vfit <- lmFit(vdg, design)
  vfit <- contrasts.fit(vfit, contrasts=contr.matrix)
  efit <- eBayes(vfit)

  vfit_filtered<-lmFit(vdg_low_filtered, design)
  vfit_filtered <- contrasts.fit(vfit_filtered, contrasts=contr.matrix)
  efit_filtered <- eBayes(vfit_filtered)
  
#Table with pvalue and mapping differentially expressed genes
  process_top_table <- function(df, p_cutoff, logFC_cutoff) {
    df %>%
      mutate(upregulation = ifelse(adj.P.Val < p_cutoff & logFC > logFC_cutoff, 1, 0)) %>%
      mutate(downregulation = ifelse(adj.P.Val < p_cutoff & logFC < -logFC_cutoff, 1, 0)) %>%
      mutate(differential.expression = ifelse(upregulation == 1 | downregulation == 1, 1, 0))
  }
  
  # Apply the function to different data frames
  top.table_log_filtered <- process_top_table(topTable(efit, n = Inf), 0.05, 0.58)
  top.table_no_filtered <- process_top_table(topTable(efit, n = Inf), 0.05, 0)
  top.table_low_filtered <- process_top_table(topTable(efit_filtered, n = Inf), 0.05, 0)
  top.table_low_log_filtered <- process_top_table(topTable(efit_filtered, n = Inf), 0.05, 0.58)
  
  top.table_log_filtered <- top.table_log_filtered[,!names(top.table_log_filtered) %in% 
                                                     c("logFC","AveExpr","t","adj.P.Val","P.Value","B")]
  top.table_no_filtered <- top.table_no_filtered[,!names(top.table_no_filtered) %in% 
                                                     c("logFC","AveExpr","t","adj.P.Val","P.Value","B")]
  top.table_low_filtered <- top.table_low_filtered[,!names(top.table_low_filtered) %in% 
                                                   c("logFC","AveExpr","t","P.Value","adj.P.Val","B")]
  top.table_low_log_filtered <- top.table_low_log_filtered[,!names(top.table_low_log_filtered) %in% 
                                                     c("logFC","AveExpr","t","P.Value","adj.P.Val","B")]
  

  output_file_log_filtered <-  paste0("Results/limmaAG/limmaAG_", filename,'_meta_log_filtered', "_Results.txt")
  output_file_no_filtered <-  paste0("Results/limmaAG/limmaAG_", filename,'_meta_no_filtered', "_Results.txt")
  output_file_low_filtered <-  paste0("Results/limmaAG/limmaAG_", filename,'_meta_low_filtered', "_Results.txt")
  output_file_low_log_filtered <-  paste0("Results/limmaAG/limmaAG_", filename,'_meta_low_log_filtered', "_Results.txt")
  
  write.table(  top.table_log_filtered, file = output_file_log_filtered , sep = "\t", quote = FALSE, row.names = FALSE)
  write.table(  top.table_no_filtered, file = output_file_no_filtered, sep = "\t", quote = FALSE, row.names = FALSE)
  write.table(  top.table_low_filtered, file = output_file_low_filtered, sep = "\t", quote = FALSE, row.names = FALSE)
  write.table(  top.table_low_log_filtered, file = output_file_low_log_filtered, sep = "\t", quote = FALSE, row.names = FALSE)
}


sample3_dge("3_500_500")
sample3_dge("3_750_250")
sample3_dge("3_1000_0")
sample3_dge("6_500_500")
sample3_dge("6_750_250")
sample3_dge("6_1000_0")
sample3_dge("9_500_500")
sample3_dge("9_750_250")
sample3_dge("9_1000_0")

